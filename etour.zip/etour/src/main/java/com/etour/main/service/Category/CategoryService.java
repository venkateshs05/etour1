package com.etour.main.service.Category;

import java.util.List;

import com.etour.main.models.CategoryMaster;

public interface CategoryService {
	public List<CategoryMaster> getCategory();
	
	

}
